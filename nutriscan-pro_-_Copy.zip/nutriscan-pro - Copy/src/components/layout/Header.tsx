import { useState } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { useToast } from '@/hooks/use-toast'
import { Button } from '@/components/ui/button'
import { ArrowRight, LogOut, Menu, X } from 'lucide-react'

interface HeaderProps {
  page: string
  setPage: (page: string) => void
}

export function Header({ page, setPage }: HeaderProps) {
  const [menuOpen, setMenuOpen] = useState(false)
  const { user, profile, signOut } = useAuth()
  const { toast } = useToast()

  const go = (nextPage: string) => {
    setPage(nextPage)
    setMenuOpen(false)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleSignOut = async () => {
    await signOut()
    toast({
      title: 'Signed out',
      description: 'You have been logged out successfully.',
    })
    go('home')
  }

  return (
    <header className="site-header">
      <a className="wordmark" href="#top" onClick={(e) => { e.preventDefault(); go('home') }}>
        <span className="leaf-dot" />
        NutriScan
      </a>

      {/* Primary Navigation */}
      <nav aria-label="Primary navigation" className={`desktop-nav${menuOpen ? ' is-open' : ''}`}>
        <button className={page === 'home' ? 'active' : ''} onClick={() => go('home')}>
          Home
        </button>
        <button className={page === 'analyze' ? 'active' : ''} onClick={() => go('analyze')}>
          Analyze
        </button>
        <button className={page === 'planner' ? 'active' : ''} onClick={() => go('planner')}>
          Meal Planner
        </button>
        <button className={page === 'progress' ? 'active' : ''} onClick={() => go('progress')}>
          Progress
        </button>
        <button className={page === 'history' ? 'active' : ''} onClick={() => go('history')}>
          Diet History
        </button>

        {user ? (
          <>
            <button className={page === 'profile' ? 'active' : ''} onClick={() => go('profile')}>
              Account
            </button>
            <button className={page === 'settings' ? 'active' : ''} onClick={() => go('settings')}>
              Settings
            </button>
            <button
              onClick={handleSignOut}
              className="text-link"
              style={{ fontSize: '13px', color: 'var(--muted)', display: 'inline-flex', alignItems: 'center', gap: '4px' }}
              title="Sign Out"
            >
              <LogOut size={14} /> Sign Out
            </button>
          </>
        ) : (
          <>
            <button className={page === 'signin' || page === 'signup' ? 'active' : ''} onClick={() => go('signin')}>
              Sign In
            </button>
            <Button onClick={() => go('analyze')} className="btn-primary">
              Get Started <ArrowRight data-icon="inline-end" size={16} />
            </Button>
          </>
        )}
      </nav>

      {/* Mobile Menu Toggle */}
      <button
        className="menu-button"
        aria-label={menuOpen ? 'Close navigation' : 'Open navigation'}
        aria-expanded={menuOpen}
        onClick={() => setMenuOpen(!menuOpen)}
      >
        {menuOpen ? <X size={22} /> : <Menu size={22} />}
      </button>
    </header>
  )
}

export default Header
