import { useState } from 'react'
import { AuthProvider } from './contexts/AuthContext'
import { Toaster } from '@/components/ui/toaster'
import { Header } from '@/components/layout/Header'
import { HomePage } from '@/pages/HomePage'
import { AnalyzePage } from '@/pages/AnalyzePage'
import { ResultPage } from '@/pages/ResultPage'
import { AuthPage } from '@/pages/AuthPage'
import { MealPlannerPage } from '@/pages/MealPlannerPage'
import { ProgressPage } from '@/pages/ProgressPage'
import { DietHistoryPage } from '@/pages/DietHistoryPage'
import { ProfilePage } from '@/pages/ProfilePage'
import { SettingsPage } from '@/pages/SettingsPage'
import { PrivacyPolicyPage } from '@/pages/PrivacyPolicyPage'
import { TermsPage } from '@/pages/TermsPage'

function AppContent() {
  const [page, setPage] = useState('home')
  const [currentAnalysis, setCurrentAnalysis] = useState<any>(null)

  return (
    <div className="app-container">
      <Header page={page} setPage={setPage} />

      {page === 'home' && <HomePage setPage={setPage} />}
      {page === 'analyze' && (
        <AnalyzePage
          setPage={setPage}
          onAnalysisComplete={(res) => setCurrentAnalysis(res)}
        />
      )}
      {page === 'results' && (
        <ResultPage
          analysisData={currentAnalysis}
          setPage={setPage}
        />
      )}
      {page === 'signin' && (
        <AuthPage
          initialMode="signin"
          setPage={setPage}
        />
      )}
      {page === 'signup' && (
        <AuthPage
          initialMode="signup"
          setPage={setPage}
        />
      )}
      {page === 'planner' && <MealPlannerPage setPage={setPage} />}
      {page === 'progress' && <ProgressPage setPage={setPage} />}
      {page === 'history' && <DietHistoryPage setPage={setPage} />}
      {page === 'profile' && <ProfilePage setPage={setPage} />}
      {page === 'settings' && <SettingsPage setPage={setPage} />}
      {page === 'privacy' && <PrivacyPolicyPage setPage={setPage} />}
      {page === 'terms' && <TermsPage setPage={setPage} />}
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
      <Toaster />
    </AuthProvider>
  )
}
