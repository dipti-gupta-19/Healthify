import { useState, useEffect, useMemo } from 'react'
import {
  ArrowRight,
  Check,
  Plus,
  RefreshCw,
  Trash2,
  X,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/AuthContext'
import { useMealPlans } from '@/hooks/useMealPlans'
import { useToast } from '@/hooks/use-toast'
import { format } from 'date-fns'
import { Footer } from '@/components/layout/Footer'
import { getFoodImage } from '@/lib/foodImages'

const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

interface MealPlannerPageProps {
  setPage: (page: string) => void
}

export function MealPlannerPage({ setPage }: MealPlannerPageProps) {
  const { profile } = useAuth()
  const {
    mealPlans,
    generating,
    generateMealPlan,
    toggleMealCompletion,
    deleteMealPlan,
    addCustomMeal
  } = useMealPlans()
  const { toast } = useToast()

  const [selectedDay, setSelectedDay] = useState('Monday')
  const [goal, setGoal] = useState<'weight-loss' | 'balanced' | 'muscle'>('balanced')
  const [calorieTarget, setCalorieTarget] = useState('2000')
  const [dietaryPreference, setDietaryPreference] = useState<'veg' | 'non-veg' | 'vegan'>('veg')

  // Custom meal modal state
  const [showAddModal, setShowAddModal] = useState(false)
  const [customForm, setCustomForm] = useState({
    food_name: '',
    meal_type: 'breakfast',
    calories: '350',
    protein: '18',
    description: '',
  })
  const [savingCustom, setSavingCustom] = useState(false)

  useEffect(() => {
    if (profile?.dietary_preference) {
      setDietaryPreference(profile.dietary_preference)
    }
    if (profile?.daily_calorie_target) {
      setCalorieTarget(String(profile.daily_calorie_target))
    }
  }, [profile])

  // Generate on first mount if mealPlans is empty (silent: true so no toast pops up on page load)
  useEffect(() => {
    if (mealPlans.length === 0 && !generating) {
      generateMealPlan(7, dietaryPreference, {
        targetDate: format(new Date(), 'yyyy-MM-dd'),
        silent: true,
      })
    }
  }, [])

  const handleGenerate = async () => {
    try {
      await generateMealPlan(7, dietaryPreference, {
        targetDate: format(new Date(), 'yyyy-MM-dd'),
        silent: false, // Toast only pops up when user explicitly clicks generate
      })
    } catch (err: any) {
      console.warn('Meal plan generation notice:', err)
    }
  }

  // Filter meal plans by the selected day
  const dayIndex = weekDays.indexOf(selectedDay)
  const uniqueDates = useMemo(() => {
    return Array.from(new Set(mealPlans.map(m => m.plan_date))).sort()
  }, [mealPlans])

  const targetDate = uniqueDates[dayIndex] || format(new Date(), 'yyyy-MM-dd')

  const mealsForDay = useMemo(() => {
    if (mealPlans.length > 0 && targetDate) {
      return mealPlans.filter(m => m.plan_date === targetDate)
    }
    return []
  }, [mealPlans, targetDate])

  const totalCalories = mealsForDay.reduce((acc, m) => acc + (m.calories || 0), 0)
  const totalProtein = mealsForDay.reduce((acc, m) => acc + (m.protein || 0), 0)

  const handleAddCustomMeal = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!customForm.food_name.trim()) {
      toast({
        title: 'Missing name',
        description: 'Please enter a name for the meal.',
        variant: 'destructive',
      })
      return
    }

    setSavingCustom(true)
    try {
      await addCustomMeal({
        plan_date: targetDate,
        meal_type: customForm.meal_type,
        food_name: customForm.food_name.trim(),
        calories: parseInt(customForm.calories) || 300,
        protein: parseFloat(customForm.protein) || 15,
        description: customForm.description.trim() || 'Custom home prepared meal',
      })
      setCustomForm({
        food_name: '',
        meal_type: 'breakfast',
        calories: '350',
        protein: '18',
        description: '',
      })
      setShowAddModal(false)
    } finally {
      setSavingCustom(false)
    }
  }

  return (
    <>
      <main className="wrap feature-page">
        <p className="kicker">PERSONAL AI NUTRITION</p>
        <h1>Plan a week that feels good.</h1>
        <p className="hero-lede">
          Tell NutriScan what you want to eat and get a practical Indian meal plan built around your exact calorie and macro targets.
        </p>

        <section className="planner-form">
          <label>
            Goal
            <select value={goal} onChange={(e) => setGoal(e.target.value as any)}>
              <option value="balanced">Balanced eating & maintenance</option>
              <option value="weight-loss">Healthy weight loss (−400 kcal)</option>
              <option value="muscle">Muscle build & high protein</option>
            </select>
          </label>
          <label>
            Daily Target (kcal)
            <input
              type="number"
              value={calorieTarget}
              onChange={(e) => setCalorieTarget(e.target.value)}
              min="1200"
              max="4000"
              step="50"
            />
          </label>
          <label>
            Diet Preference
            <select
              value={dietaryPreference}
              onChange={(e) => setDietaryPreference(e.target.value as any)}
            >
              <option value="veg">Indian Vegetarian</option>
              <option value="non-veg">Non-Vegetarian (Chicken / Egg / Fish)</option>
              <option value="vegan">Pure Plant-Based Vegan</option>
            </select>
          </label>
          <Button onClick={handleGenerate} disabled={generating} className="btn-primary">
            {generating ? (
              <>
                <RefreshCw size={16} className="animate-spin" /> Generating...
              </>
            ) : (
              <>
                Regenerate AI Plan <ArrowRight data-icon="inline-end" size={16} />
              </>
            )}
          </Button>
        </section>

        <section style={{ marginTop: '30px' }}>
          {/* Week Day Tabs */}
          <div className="day-tabs">
            {weekDays.map((d) => (
              <button
                key={d}
                className={`day-tab ${selectedDay === d ? 'active' : ''}`}
                onClick={() => setSelectedDay(d)}
              >
                {d}
              </button>
            ))}
          </div>

          {/* Day Summary Banner */}
          <div className="day-summary-banner">
            <div className="day-summary-info">
              <span className="day-summary-kicker">{selectedDay.toUpperCase()} OVERVIEW</span>
              <span className="day-summary-stats">
                {totalCalories > 0 ? `${totalCalories} kcal total · ${totalProtein}g Protein` : 'Personalized AI Meal Plan'}
              </span>
            </div>
            <button
              onClick={() => setShowAddModal(true)}
              className="outline-button day-summary-add-btn"
            >
              <Plus size={14} /> Add Custom Meal
            </button>
          </div>

          {/* Meal Cards Grid */}
          <div className="meal-cards-grid">
            {mealsForDay.length > 0 ? (
              mealsForDay.map((item) => (
                <article className="meal-card" key={item.id}>
                  <div className="meal-card-media">
                    <img
                      src={getFoodImage(item.food_name, item.meal_type)}
                      alt={item.food_name}
                      loading="lazy"
                    />
                  </div>
                  <div className="meal-card-body">
                    <div className="meal-card-header">
                      <span className="meal-card-type">{item.meal_type.toUpperCase()}</span>
                      <div className="meal-card-actions">
                        <button
                          type="button"
                          onClick={() => toggleMealCompletion(item.id)}
                          className={`meal-status-btn ${item.is_completed ? 'completed' : ''}`}
                        >
                          <Check size={12} /> {item.is_completed ? 'Eaten' : 'Mark Eaten'}
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteMealPlan(item.id)}
                          className="meal-delete-btn"
                          title="Delete this meal"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                    <h3 className="meal-card-title">{item.food_name}</h3>
                    <p className="meal-card-desc">{item.description || 'Nutrient-rich balanced meal formulated by AI.'}</p>
                    <div className="meal-card-footer">
                      <span className="meal-calories">{item.calories} kcal</span>
                      <span className="meal-protein">{item.protein}g protein</span>
                    </div>
                  </div>
                </article>
              ))
            ) : (
              <div style={{ padding: '40px 20px', textAlign: 'center', gridColumn: '1 / -1', background: 'var(--surface)', border: '1px dashed var(--line)', borderRadius: 'var(--radius-lg)' }}>
                <p className="muted" style={{ margin: '0 0 16px' }}>
                  No meals found for {selectedDay}.
                </p>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '12px' }}>
                  <Button onClick={() => setShowAddModal(true)} className="btn-primary">
                    <Plus size={16} /> Add Custom Meal
                  </Button>
                  <button onClick={handleGenerate} className="outline-button">
                    <RefreshCw size={14} /> Generate 7-Day Plan
                  </button>
                </div>
              </div>
            )}
          </div>
        </section>
      </main>

      {/* Add Custom Meal Modal */}
      {showAddModal && (
        <div className="modal-backdrop" onClick={() => setShowAddModal(false)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <p className="kicker" style={{ margin: 0 }}>NEW MEAL FOR {selectedDay.toUpperCase()}</p>
                <h2>Add Custom Meal</h2>
              </div>
              <button
                type="button"
                className="modal-close-btn"
                onClick={() => setShowAddModal(false)}
                aria-label="Close modal"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleAddCustomMeal} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <div className="form-group">
                <label>Dish Name *</label>
                <input
                  className="form-input"
                  required
                  placeholder="e.g. Spiced Paneer Bhurji & Multigrain Rotis"
                  value={customForm.food_name}
                  onChange={(e) => setCustomForm({ ...customForm, food_name: e.target.value })}
                />
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                <div className="form-group">
                  <label>Meal Time</label>
                  <select
                    className="form-input"
                    value={customForm.meal_type}
                    onChange={(e) => setCustomForm({ ...customForm, meal_type: e.target.value })}
                  >
                    <option value="breakfast">Breakfast</option>
                    <option value="lunch">Lunch</option>
                    <option value="dinner">Dinner</option>
                    <option value="snack">Snack</option>
                  </select>
                </div>

                <div className="form-group">
                  <label>Calories (kcal) *</label>
                  <input
                    className="form-input"
                    type="number"
                    required
                    min="10"
                    max="3000"
                    value={customForm.calories}
                    onChange={(e) => setCustomForm({ ...customForm, calories: e.target.value })}
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Protein (grams)</label>
                <input
                  className="form-input"
                  type="number"
                  min="0"
                  max="200"
                  value={customForm.protein}
                  onChange={(e) => setCustomForm({ ...customForm, protein: e.target.value })}
                />
              </div>

              <div className="form-group">
                <label>Description / Ingredients</label>
                <input
                  className="form-input"
                  placeholder="e.g. Made with low-fat paneer, capsicum, and fresh coriander"
                  value={customForm.description}
                  onChange={(e) => setCustomForm({ ...customForm, description: e.target.value })}
                />
              </div>

              <div style={{ display: 'flex', gap: '12px', marginTop: '10px' }}>
                <Button type="submit" disabled={savingCustom} className="btn-primary" style={{ flex: 1 }}>
                  {savingCustom ? 'Adding...' : 'Add to Plan'}
                </Button>
                <button
                  type="button"
                  className="outline-button"
                  onClick={() => setShowAddModal(false)}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <Footer setPage={setPage} />
    </>
  )
}

export default MealPlannerPage
