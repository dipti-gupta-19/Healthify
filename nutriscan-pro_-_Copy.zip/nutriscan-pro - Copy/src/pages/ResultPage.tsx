import { useState } from 'react'
import {
  ArrowRight,
  BookmarkCheck,
  ChevronDown,
  Send,
  Sparkles,
  X,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/AuthContext'
import { useMeals } from '@/hooks/useMeals'
import { useToast } from '@/hooks/use-toast'
import { Footer } from '@/components/layout/Footer'

import { getFoodImage } from '@/lib/foodImages'
import { BotAvatarSvg } from '@/components/ui/BotAvatarSvg'

interface ResultPageProps {
  analysisData: any
  setPage: (page: string) => void
}

export function ResultPage({
  analysisData,
  setPage,
}: ResultPageProps) {
  const [chatOpen] = useState(true)
  const [mobileChatOpen, setMobileChatOpen] = useState(false)
  const [healthOpen, setHealthOpen] = useState(true)
  const [savingMeal, setSavingMeal] = useState(false)
  const [mealSaved, setMealSaved] = useState(false)

  const { user } = useAuth()
  const { addMeal } = useMeals()
  const { toast } = useToast()

  const dishName = analysisData?.foodName || 'Cheese Pizza with Green Bell Peppers'
  const calories = analysisData?.calories || 300
  const protein = analysisData?.protein || 13
  const carbs = analysisData?.carbs || 35
  const fat = analysisData?.fat || 12
  const fiber = analysisData?.fiber || 2
  const sugar = analysisData?.sugar || 4
  const sodium = analysisData?.sodium || 650
  const healthScore = typeof analysisData?.healthScore === 'object'
    ? (analysisData?.healthScore?.score || 65)
    : (Number(analysisData?.healthScore) || 65)
  const uploadedPhoto = analysisData?.imageUrl || (typeof window !== 'undefined' ? sessionStorage.getItem('nutriscan_last_image') : null)
  const image = uploadedPhoto || getFoodImage(dishName)

  const [messages, setMessages] = useState([
    {
      sender: 'bot',
      text: `I've analyzed your ${dishName}.\n\n• Energy: ${calories} kcal\n• Protein: ${protein}g · Carbs: ${carbs}g · Fat: ${fat}g\n• Health Score: ${healthScore}/100`
    }
  ])
  const [inputText, setInputText] = useState('')

  const handleSaveToDiary = async () => {
    if (!user) {
      toast({
        title: 'Sign in required',
        description: 'Please sign in to save this meal to your personal diet history.',
        variant: 'destructive',
      })
      setPage('signin')
      return
    }

    setSavingMeal(true)
    try {
      await addMeal({
        food_name: dishName,
        description: analysisData?.description || 'Scanned meal with AI nutrition estimation',
        calories: Number(calories),
        protein: Number(protein),
        carbs: Number(carbs),
        fat: Number(fat),
        fiber: Number(fiber),
        sugar: Number(sugar),
        sodium: Number(sodium),
        serving_size: analysisData?.servingSize || '1 serving',
        meal_type: 'lunch',
        image_url: null,
        logged_at: new Date().toISOString(),
        health_score: Number(healthScore),
      })
      setMealSaved(true)
      toast({
        title: 'Meal saved!',
        description: `${dishName} has been recorded into your diet history.`,
      })
    } catch (err: any) {
      toast({
        title: 'Error saving meal',
        description: err?.message || 'Failed to record meal to database',
        variant: 'destructive',
      })
    } finally {
      setSavingMeal(false)
    }
  }

  const sendMessage = (textToSend?: string) => {
    const text = textToSend || inputText
    if (!text.trim()) return

    const newMessages = [...messages, { sender: 'user', text }]
    setMessages(newMessages)
    setInputText('')

    setTimeout(() => {
      let botReply = `Great question! Based on ${dishName}, you have ${protein}g of protein. Adding a bowl of sprouted dal or grilled tofu would balance out the carb ratio nicely.`
      if (text.toLowerCase().includes('burn')) {
        botReply = `To burn approx. ${calories} kcal: 35 minutes of brisk walking (5.5 km/h), 25 minutes of cycling, or 20 minutes of jogging.`
      } else if (text.toLowerCase().includes('loss')) {
        botReply = 'For weight loss, pair this with a high-fiber green salad with lemon dressing to enhance satiety and slow gastric emptying.'
      }
      setMessages([...newMessages, { sender: 'bot', text: botReply }])
    }, 600)
  }

  const macrosList = [
    ['Protein', `${protein}g`, `${protein * 4} kcal`, `${Math.round((protein * 4 / calories) * 100)}%`, 'green'],
    ['Carbs', `${carbs}g`, `${carbs * 4} kcal`, `${Math.round((carbs * 4 / calories) * 100)}%`, 'amber'],
    ['Fat', `${fat}g`, `${fat * 9} kcal`, `${Math.round((fat * 9 / calories) * 100)}%`, 'orange'],
    ['Fiber', `${fiber}g`, '—', '12%', 'green'],
    ['Sugar', `${sugar}g`, '—', '8%', 'orange']
  ]

  return (
    <>
      <main className="wrap results-page">
        <div className="results-top">
          <div>
            <p className="kicker">ANALYSIS COMPLETE</p>
            <h1>Your meal, broken down.</h1>
          </div>
          <div style={{ display: 'flex', gap: '12px' }}>
            <button className="text-link" onClick={() => setPage('analyze')}>
              Analyze another food <ArrowRight size={14} />
            </button>
          </div>
        </div>

        <div className="results-layout">
          {/* Main Results Column */}
          <div className="main-results">
            {/* Dish Overview */}
            <section className="dish-intro">
              <img
                src={image}
                alt={dishName}
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = getFoodImage(dishName)
                }}
              />
              <div>
                <div className="tag">
                  <Sparkles size={12} /> 95% AI confidence
                </div>
                <h2>{dishName}</h2>
                <p>{analysisData?.description || 'Authentic dish deconstructed into individual ingredients, portion weights, and macro breakdown.'}</p>
                <span className="muted" style={{ fontSize: '13px', fontFamily: 'var(--font-mono)' }}>
                  Portion: {analysisData?.servingSize || '1 serving (approx 300g)'}
                </span>
              </div>
            </section>

            {/* Total Energy Label */}
            <section className="nutrition-label">
              <div className="label-title">TOTAL ENERGY</div>
              <div className="big-number">
                {calories} <small>kcal</small>
              </div>
              <p className="muted" style={{ margin: '4px 0 0', fontSize: '13px' }}>
                {Math.round((calories / 2000) * 100)}% of your recommended 2,000 kcal daily target
              </p>
              <div className="macro-bar">
                <i style={{ width: `${Math.round((protein * 4 / calories) * 100)}%` }} />
                <i style={{ width: `${Math.round((carbs * 4 / calories) * 100)}%` }} />
                <i style={{ width: `${Math.round((fat * 9 / calories) * 100)}%` }} />
              </div>
              <div className="bar-legend">
                <span>Protein <b>{protein}g · {protein * 4} kcal</b></span>
                <span>Carbs <b>{carbs}g · {carbs * 4} kcal</b></span>
                <span>Fat <b>{fat}g · {fat * 9} kcal</b></span>
              </div>
            </section>

            {/* Macronutrient Table */}
            <section className="macro-table">
              <div className="table-head">
                <span>MACRONUTRIENT</span>
                <span>AMOUNT</span>
                <span>CALORIES</span>
                <span>% ENERGY</span>
              </div>
              {macrosList.map(([name, amount, kcal, pct, color]) => (
                <div className="macro-row" key={name}>
                  <strong>{name}</strong>
                  <b>{amount}</b>
                  <span>{kcal}</span>
                  <div>
                    <span>{pct}</span>
                    <i className={color} style={{ width: pct }} />
                  </div>
                </div>
              ))}
            </section>

            {/* Sodium and Micronutrients */}
            <section className="sodium-row">
              <div>
                <span className="label-small">SODIUM ESTIMATE</span>
                <strong>{sodium} mg</strong>
              </div>
              <span className="status moderate">Moderate</span>
              <div className="line-bar">
                <i style={{ width: `${Math.min(100, Math.round((sodium / 2300) * 100))}%` }} />
              </div>
              <small>{Math.round((sodium / 2300) * 100)}% of recommended daily limit (2,300 mg)</small>
            </section>

            {/* Health Score Accordion */}
            <section className="health-section">
              <button className="collapse-head" onClick={() => setHealthOpen(!healthOpen)}>
                <span style={{ fontSize: '13px', fontWeight: 600 }}>HEALTH SCORE BREAKDOWN</span>
                <span className="status moderate">
                  Score {healthScore}/100 <ChevronDown className={healthOpen ? 'rotate' : ''} />
                </span>
              </button>
              {healthOpen && (
                <div className="health-body">
                  <div className="score-number">
                    {healthScore} <small>/ 100</small>
                  </div>
                  <p>
                    <strong>Nutritional verdict:</strong> Provides solid energy and micronutrients. Optimizing your fiber-to-carb ratio can enhance metabolic impact.
                  </p>
                  <div className="improve">
                    <strong style={{ fontSize: '14px' }}>How to optimize this meal:</strong>
                    <ol>
                      <li>Add a colorful cucumber-tomato salad with lemon dressing to double dietary fiber.</li>
                      <li>Include an additional lean protein source (egg, paneer, tofu, or lentils).</li>
                      <li>Stay hydrated with a glass of water to promote nutrient absorption.</li>
                    </ol>
                  </div>
                </div>
              )}
            </section>

            {/* Result Actions */}
            <div className="result-actions">
              <Button
                onClick={handleSaveToDiary}
                disabled={savingMeal || mealSaved}
                className="btn-primary"
              >
                {mealSaved ? (
                  <>
                    <BookmarkCheck size={16} /> Saved to Diary
                  </>
                ) : (
                  <>
                    <BookmarkCheck size={16} /> Save to My Diary
                  </>
                )}
              </Button>
              <button className="outline-button" onClick={() => setPage('planner')}>
                Open AI Meal Planner
              </button>
              <button className="outline-button" onClick={() => setPage('history')}>
                View Diet History
              </button>
            </div>
          </div>

          {/* Desktop NutriBot Sidebar */}
          <aside className={`nutribot ${chatOpen ? '' : 'closed'}`}>
            <div className="bot-head">
              <div>
                <b style={{ display: 'inline-flex', alignItems: 'center', gap: '7px' }}>
                  NutriBot AI
                  <BotAvatarSvg size={22} color="var(--green)" />
                </b>
                <span>Ask about {dishName}</span>
              </div>
            </div>
            <div className="question-scroll">
              <button onClick={() => sendMessage('How to burn these calories?')}>How to burn this?</button>
              <button onClick={() => sendMessage('Is this good for weight loss?')}>Weight loss friendly?</button>
              <button onClick={() => sendMessage('How can I add more protein?')}>Boost protein</button>
            </div>
            <div className="messages">
              {messages.map((m, idx) => (
                <div key={idx} className={m.sender === 'bot' ? 'bot-message' : 'user-message'}>
                  {m.sender === 'bot' && (
                    <div style={{ marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <BotAvatarSvg size={15} color="var(--green)" />
                      <span style={{ fontSize: '11px', fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--green)' }}>NutriBot</span>
                    </div>
                  )}
                  {m.text}
                </div>
              ))}
            </div>
            <div className="chat-input">
              <input
                placeholder="Ask anything about this meal..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') sendMessage() }}
              />
              <button onClick={() => sendMessage()} type="button">
                <Send size={15} />
              </button>
            </div>
          </aside>
        </div>
      </main>

      {/* Mobile Floating Chat Button */}
      <button className="mobile-chat-trigger" onClick={() => setMobileChatOpen(true)}>
        <BotAvatarSvg size={18} color="#ffffff" /> Ask NutriBot
      </button>

      {/* Mobile NutriBot Bottom Drawer */}
      {mobileChatOpen && (
        <>
          <div className="mobile-drawer-backdrop" onClick={() => setMobileChatOpen(false)} />
          <aside className="nutribot mobile-open">
            <div className="bot-head">
              <div>
                <b style={{ display: 'inline-flex', alignItems: 'center', gap: '7px' }}>
                  NutriBot AI
                  <BotAvatarSvg size={22} color="var(--green)" />
                </b>
                <span>Ask about {dishName}</span>
              </div>
              <button onClick={() => setMobileChatOpen(false)} aria-label="Close chat">
                <X size={20} />
              </button>
            </div>
            <div className="question-scroll">
              <button onClick={() => sendMessage('How to burn these calories?')}>How to burn this?</button>
              <button onClick={() => sendMessage('Is this good for weight loss?')}>Weight loss?</button>
              <button onClick={() => sendMessage('Boost protein')}>Boost protein</button>
            </div>
            <div className="messages">
              {messages.map((m, idx) => (
                <div key={idx} className={m.sender === 'bot' ? 'bot-message' : 'user-message'}>
                  {m.sender === 'bot' && (
                    <div style={{ marginBottom: '6px', display: 'flex', alignItems: 'center', gap: '5px' }}>
                      <BotAvatarSvg size={15} color="var(--green)" />
                      <span style={{ fontSize: '11px', fontFamily: 'var(--font-mono)', fontWeight: 600, color: 'var(--green)' }}>NutriBot</span>
                    </div>
                  )}
                  {m.text}
                </div>
              ))}
            </div>
            <div className="chat-input">
              <input
                placeholder="Ask anything..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') sendMessage() }}
              />
              <button onClick={() => sendMessage()} type="button">
                <Send size={15} />
              </button>
            </div>
          </aside>
        </>
      )}

      <Footer setPage={setPage} />
    </>
  )
}

export default ResultPage
