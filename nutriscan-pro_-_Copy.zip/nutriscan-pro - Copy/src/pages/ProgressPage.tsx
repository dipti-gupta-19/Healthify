import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useMeals } from '@/hooks/useMeals'
import { Footer } from '@/components/layout/Footer'

interface ProgressPageProps {
  setPage: (page: string) => void
}

export function ProgressPage({ setPage }: ProgressPageProps) {
  const { todayStats, weeklyStats } = useMeals()

  const avgCalories = weeklyStats?.averageDailyCalories || todayStats?.totalCalories || 1970
  const avgHealthScore = todayStats?.averageHealthScore || 74
  const mealCount = weeklyStats?.totalMeals || (todayStats?.mealCount || 4)

  const chartDays = [
    { day: 'Mon', kcal: 1940, target: 2000, height: 75 },
    { day: 'Tue', kcal: 2080, target: 2000, height: 82, over: true },
    { day: 'Wed', kcal: 1890, target: 2000, height: 71 },
    { day: 'Thu', kcal: 1980, target: 2000, height: 78 },
    { day: 'Fri', kcal: 2150, target: 2000, height: 86, over: true },
    { day: 'Sat', kcal: 1820, target: 2000, height: 68 },
    { day: 'Sun', kcal: 1950, target: 2000, height: 76 }
  ]

  return (
    <>
      <main className="wrap feature-page">
        <p className="kicker">YOUR SIGNAL & PATTERNS</p>
        <h1>Progress you can feel.</h1>
        <p className="hero-lede">
          Small consistent choices add up. Review your weekly caloric consistency, macronutrient distributions, and tracking streak.
        </p>

        {/* Top 3 Metric Cards */}
        <section className="feature-grid">
          <article className="feature-card">
            <span className="kicker">AVERAGE CALORIES</span>
            <strong className="feature-number">{avgCalories}</strong>
            <p>Average daily kcal across {mealCount} tracked meals.</p>
          </article>
          <article className="feature-card">
            <span className="kicker">AVG HEALTH SCORE</span>
            <strong className="feature-number" style={{ color: '#b45309' }}>{Math.round(avgHealthScore)}</strong>
            <p>Score benchmarked from nutritional density.</p>
          </article>
          <article className="feature-card">
            <span className="kicker">LOGGING STREAK</span>
            <strong className="feature-number">12 Days</strong>
            <p>You have logged every meal consistently.</p>
          </article>
        </section>

        {/* Visual Calorie Bar Chart */}
        <section className="progress-chart-card">
          <div className="chart-header">
            <div>
              <span className="kicker">CALORIE INTAKE VS TARGET</span>
              <h3>Weekly Consistency (Target: 2,000 kcal)</h3>
            </div>
            <span className="chart-target-badge">98.6% On Target</span>
          </div>

          <div className="bar-chart-visual">
            <div className="chart-target-line">
              <span>Goal: 2,000 kcal</span>
            </div>
            {chartDays.map((col) => (
              <div className="chart-col" key={col.day}>
                <b>{col.kcal}</b>
                <div
                  className={`chart-bar-fill ${col.over ? 'over' : ''}`}
                  style={{ height: `${col.height}%` }}
                />
                <span>{col.day}</span>
              </div>
            ))}
          </div>

          {/* Macro Breakdown */}
          <div className="macro-split-grid">
            <div className="macro-split-item">
              <span>PROTEIN (AVG 105g / 120g TARGET)</span>
              <strong>88% TARGET</strong>
              <div className="macro-progress-bar">
                <i style={{ width: '88%', background: 'var(--green)' }} />
              </div>
            </div>
            <div className="macro-split-item">
              <span>CARBS (AVG 210g / 220g TARGET)</span>
              <strong>95% TARGET</strong>
              <div className="macro-progress-bar">
                <i style={{ width: '95%', background: '#d79a28' }} />
              </div>
            </div>
            <div className="macro-split-item">
              <span>FATS (AVG 58g / 65g TARGET)</span>
              <strong>89% TARGET</strong>
              <div className="macro-progress-bar">
                <i style={{ width: '89%', background: 'var(--terracotta)' }} />
              </div>
            </div>
          </div>
        </section>

        <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap' }}>
          <Button onClick={() => setPage('analyze')} className="btn-primary">
            Log another meal <ArrowRight data-icon="inline-end" size={16} />
          </Button>
          <button className="outline-button" onClick={() => setPage('history')}>
            View Meal History
          </button>
        </div>
      </main>
      <Footer setPage={setPage} />
    </>
  )
}

export default ProgressPage
