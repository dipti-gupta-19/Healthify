import { useState, useMemo } from 'react'
import {
  ArrowRight,
  Download,
  Search,
  Trash2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useMeals } from '@/hooks/useMeals'
import { useToast } from '@/hooks/use-toast'
import { format, parseISO } from 'date-fns'
import { Footer } from '@/components/layout/Footer'

import { getFoodImage } from '@/lib/foodImages'

const sampleImage = `${import.meta.env.BASE_URL}biryani-sample.png`
const resultImage = `${import.meta.env.BASE_URL}placeholder.jpg`

interface DietHistoryPageProps {
  setPage: (page: string) => void
}

export function DietHistoryPage({ setPage }: DietHistoryPageProps) {
  const { meals, deleteMeal } = useMeals()
  const { toast } = useToast()

  const [filter, setFilter] = useState('all')
  const [search, setSearch] = useState('')

  // If user has database meals, use them; otherwise use representative Indian diet meals
  const displayMeals = useMemo(() => {
    if (meals.length > 0) {
      return meals.map(m => ({
        id: m.id,
        title: m.food_name,
        time: format(parseISO(m.logged_at), 'MMM dd, yyyy · h:mm a'),
        calories: m.calories,
        score: m.health_score || 70,
        img: m.image_url || getFoodImage(m.food_name, m.meal_type),
        macros: `${m.protein}g P · ${m.carbs}g C · ${m.fat}g F`,
        raw: m
      }))
    }
    return [
      {
        id: 'sample-1',
        title: 'Hyderabadi Chicken Biryani',
        time: 'Today · 1:30 PM (Lunch)',
        calories: 538,
        score: 68,
        img: sampleImage,
        macros: '26g P · 62g C · 18g F',
        raw: null
      },
      {
        id: 'sample-2',
        title: 'Cheese Pizza with Bell Peppers',
        time: 'Yesterday · 8:15 PM (Dinner)',
        calories: 300,
        score: 55,
        img: resultImage,
        macros: '13g P · 35g C · 12g F',
        raw: null
      },
      {
        id: 'sample-3',
        title: 'Moong Dal Chilla & Curd',
        time: 'Yesterday · 9:00 AM (Breakfast)',
        calories: 340,
        score: 84,
        img: getFoodImage('Moong Dal Chilla & Curd', 'breakfast'),
        macros: '18g P · 38g C · 8g F',
        raw: null
      }
    ]
  }, [meals])

  const filteredMeals = displayMeals.filter((m) => {
    const matchesSearch = m.title.toLowerCase().includes(search.toLowerCase())
    if (filter === 'today') return matchesSearch && m.time.toLowerCase().includes('today')
    if (filter === 'yesterday') return matchesSearch && m.time.toLowerCase().includes('yesterday')
    return matchesSearch
  })

  const triggerExport = () => {
    const headers = 'Dish Name,Timestamp,Calories,Protein,Carbs,Fat,Health Score\n'
    const rows = filteredMeals
      .map(m => `"${m.title}","${m.time}",${m.calories},"${m.macros}",${m.score}`)
      .join('\n')
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `nutriscan_diet_history_${format(new Date(), 'yyyy-MM-dd')}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast({
      title: 'Diet history exported',
      description: 'Downloaded CSV file with all logged meals and nutritional details.',
    })
  }

  const handleDelete = async (id: string, isSample: boolean) => {
    if (isSample) {
      toast({
        title: 'Sample item',
        description: 'Log your own food scans to manage custom diary items.',
      })
      return
    }
    await deleteMeal(id)
    toast({
      title: 'Meal removed',
      description: 'The meal has been deleted from your history.',
    })
  }

  return (
    <>
      <main className="wrap feature-page">
        <p className="kicker">YOUR MEALS & ARCHIVE</p>
        <h1>A clearer food history.</h1>
        <p className="hero-lede">
          Review recent food scans, filter by date, and export your logged nutritional records to CSV.
        </p>

        {/* Search & Filter Bar */}
        <div className="history-controls">
          <div className="history-search">
            <Search />
            <input
              placeholder="Search logged meals..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <div className="filter-pills">
            {['all', 'today', 'yesterday'].map((f) => (
              <button
                key={f}
                className={`filter-pill ${filter === f ? 'active' : ''}`}
                onClick={() => setFilter(f)}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>

          <button className="outline-button" onClick={triggerExport} style={{ height: '42px', fontSize: '13px' }}>
            <Download size={15} /> Export CSV
          </button>
        </div>

        {/* Meal History Items */}
        <section className="history-list">
          {filteredMeals.length === 0 ? (
            <p className="muted" style={{ padding: '40px 0', textAlign: 'center' }}>
              No meals match your filter criteria.
            </p>
          ) : (
            filteredMeals.map((item) => (
              <article className="history-card" key={item.id}>
                <img src={item.img} alt={item.title} />
                <div className="history-card-content">
                  <span className="kicker">{item.time}</span>
                  <h2>{item.title}</h2>
                  <div className="history-card-stats">
                    <span style={{ fontWeight: 600, color: 'var(--text)' }}>{item.calories} kcal</span>
                    <span>•</span>
                    <span className="status" style={{ fontSize: '11px', padding: '2px 8px' }}>
                      Score {item.score}/100
                    </span>
                    <span>•</span>
                    <span>{item.macros}</span>
                  </div>
                </div>
                <div className="history-card-actions">
                  <button className="text-link" onClick={() => setPage('results')}>
                    View Label <ArrowRight size={14} />
                  </button>
                  {item.raw && (
                    <button
                      onClick={() => handleDelete(item.id, !item.raw)}
                      style={{ border: 0, background: 'none', color: '#991b1b', padding: '6px' }}
                      title="Delete meal"
                    >
                      <Trash2 size={16} />
                    </button>
                  )}
                </div>
              </article>
            ))
          )}
        </section>

        <Button onClick={() => setPage('analyze')} className="btn-primary">
          Analyze a new meal <ArrowRight data-icon="inline-end" size={16} />
        </Button>
      </main>
      <Footer setPage={setPage} />
    </>
  )
}

export default DietHistoryPage
