import { useState, useEffect } from 'react'
import {
  ArrowRight,
  Eye,
  EyeOff,
  ShieldCheck,
  Sparkles,
  Zap,
  ArrowLeft,
  CheckCircle2,
  AlertCircle
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useAuth } from '@/contexts/AuthContext'
import { useToast } from '@/hooks/use-toast'
import { supabase } from '@/integrations/supabase/client'
import { SampleLabel } from '@/components/home/SampleLabel'

interface AuthPageProps {
  initialMode?: 'signin' | 'signup' | 'forgot'
  setPage: (page: string) => void
}

export function AuthPage({
  initialMode = 'signin',
  setPage,
}: AuthPageProps) {
  const [mode, setMode] = useState<'signin' | 'signup' | 'forgot'>(initialMode)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(true)
  const [loading, setLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')
  const [verificationSent, setVerificationSent] = useState(false)
  const [forgotSent, setForgotSent] = useState(false)

  const { signIn, signUp, user } = useAuth()
  const { toast } = useToast()

  // If already authenticated, redirect to home
  useEffect(() => {
    if (user) {
      setPage('home')
    }
  }, [user, setPage])

  const handleGoogleOAuth = async () => {
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin + import.meta.env.BASE_URL,
        },
      })
      if (error) {
        toast({
          title: 'Google sign-in error',
          description: error.message,
          variant: 'destructive',
        })
      }
    } catch (err: any) {
      toast({
        title: 'Sign in error',
        description: err?.message || 'Failed to initiate Google sign in',
        variant: 'destructive',
      })
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setErrorMsg('')
    setLoading(true)

    try {
      if (mode === 'signup') {
        const { error } = await signUp(email, password, name)
        if (error) {
          const msg = error.message.toLowerCase()
          if (msg.includes('already registered')) {
            setErrorMsg('This email is already registered. Please sign in instead.')
          } else {
            setErrorMsg(error.message)
          }
        } else {
          setVerificationSent(true)
          toast({
            title: 'Verification email sent',
            description: 'Please check your email to confirm your account.',
          })
        }
      } else if (mode === 'signin') {
        const { error } = await signIn(email, password)
        if (error) {
          const msg = error.message.toLowerCase()
          if (msg.includes('email not confirmed')) {
            setErrorMsg('Please verify your email address. Check your inbox for the confirmation link.')
          } else {
            setErrorMsg(error.message || 'Invalid email or password.')
          }
        } else {
          toast({
            title: 'Welcome back!',
            description: 'Successfully signed in.',
          })
          setPage('home')
        }
      } else if (mode === 'forgot') {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}${import.meta.env.BASE_URL}auth/reset-password`,
        })
        if (error) {
          setErrorMsg(error.message)
        } else {
          setForgotSent(true)
          toast({
            title: 'Reset link sent',
            description: `We've sent a password reset email to ${email}`,
          })
        }
      }
    } catch (err: any) {
      setErrorMsg(err?.message || 'An unexpected error occurred. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="auth-page">
      {/* Left Column: Form */}
      <div className="auth-form-wrap">
        <div className="auth-header-row">
          <p className="kicker" style={{ margin: 0 }}>NUTRISCAN ACCOUNT</p>
          {mode !== 'forgot' && (
            <div className="auth-tabs compact" role="tablist">
              <button
                className={`auth-tab ${mode === 'signin' ? 'active' : ''}`}
                onClick={() => { setMode('signin'); setErrorMsg(''); setVerificationSent(false); setForgotSent(false) }}
                type="button"
              >
                Sign In
              </button>
              <button
                className={`auth-tab ${mode === 'signup' ? 'active' : ''}`}
                onClick={() => { setMode('signup'); setErrorMsg(''); setVerificationSent(false); setForgotSent(false) }}
                type="button"
              >
                Create Account
              </button>
            </div>
          )}
        </div>

        {errorMsg && (
          <div style={{
            background: '#fef2f2',
            border: '1px solid #fecaca',
            color: '#dc2626',
            borderRadius: '8px',
            padding: '12px 14px',
            fontSize: '13px',
            marginTop: '12px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            <AlertCircle size={16} style={{ flexShrink: 0 }} />
            <span>{errorMsg}</span>
          </div>
        )}

        {mode === 'signin' && (
          <>
            <h1 style={{ marginTop: '12px' }}>Welcome back.</h1>
            <p className="muted" style={{ marginBottom: '20px' }}>Sign in to continue analyzing your meals and tracking your health goals.</p>

            {/* Google Login First */}
            <button type="button" className="btn-oauth" onClick={handleGoogleOAuth} style={{ marginTop: 0 }}>
              <svg width="18" height="18" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              Continue with Google
            </button>

            <div className="auth-divider">OR CONTINUE WITH EMAIL</div>

            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="signin-email">Email Address</label>
                <input
                  id="signin-email"
                  className="form-input"
                  required
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label htmlFor="signin-password">
                  <span>Password</span>
                  <button
                    type="button"
                    className="text-link"
                    style={{ fontSize: '12px' }}
                    onClick={() => { setMode('forgot'); setErrorMsg(''); setForgotSent(false) }}
                  >
                    Forgot password?
                  </button>
                </label>
                <div className="password-input-wrap">
                  <input
                    id="signin-password"
                    className="form-input"
                    required
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    className="password-toggle"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <div className="form-row">
                <label className="form-checkbox-label">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                  />
                  <span>Remember me for 30 days</span>
                </label>
              </div>

              <Button type="submit" disabled={loading} className="btn-primary" style={{ width: '100%', height: '44px' }}>
                {loading ? 'Signing in...' : 'Sign In'} <ArrowRight data-icon="inline-end" size={16} />
              </Button>
            </form>

            <p className="auth-links">
              Don't have an account?{' '}
              <button onClick={() => { setMode('signup'); setErrorMsg('') }}>Sign up free</button>
            </p>
          </>
        )}

        {mode === 'signup' && (
          <>
            <h1 style={{ marginTop: '12px' }}>Start with clarity.</h1>
            <p className="muted" style={{ marginBottom: '20px' }}>Create your free account to track nutrition history, macros, and AI meal plans.</p>

            {verificationSent ? (
              <div className="auth-success-box">
                <CheckCircle2 size={36} color="var(--green)" style={{ margin: '0 auto 12px' }} />
                <h3>Verify your email address</h3>
                <p>
                  We have sent a verification email to <strong>{email}</strong>. Please open the link in your email to confirm your account and sign in.
                </p>
                <Button
                  onClick={() => { setMode('signin'); setVerificationSent(false); setErrorMsg('') }}
                  className="btn-primary"
                  style={{ marginTop: '20px', width: '100%' }}
                >
                  Go to Sign In
                </Button>
              </div>
            ) : (
              <>
                {/* Google Signup First */}
                <button type="button" className="btn-oauth" onClick={handleGoogleOAuth} style={{ marginTop: 0 }}>
                  <svg width="18" height="18" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  Sign up with Google
                </button>

                <div className="auth-divider">OR SIGN UP WITH EMAIL</div>

                <form onSubmit={handleSubmit}>
                  <div className="form-group">
                    <label htmlFor="signup-name">Full Name</label>
                    <input
                      id="signup-name"
                      className="form-input"
                      required
                      placeholder="e.g. Alex Sharma"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="signup-email">Email Address</label>
                    <input
                      id="signup-email"
                      className="form-input"
                      required
                      type="email"
                      placeholder="name@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="signup-password">Create Password</label>
                    <div className="password-input-wrap">
                      <input
                        id="signup-password"
                        className="form-input"
                        required
                        type={showPassword ? 'text' : 'password'}
                        placeholder="At least 6 characters"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <button
                        type="button"
                        className="password-toggle"
                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  <div className="form-row">
                    <label className="form-checkbox-label">
                      <input type="checkbox" required defaultChecked />
                      <span style={{ fontSize: '12px' }}>
                        I agree to the <a href="#terms" onClick={(e) => { e.preventDefault(); setPage('terms') }} style={{ color: 'var(--green)', textDecoration: 'underline' }}>Terms</a> and{' '}
                        <a href="#privacy" onClick={(e) => { e.preventDefault(); setPage('privacy') }} style={{ color: 'var(--green)', textDecoration: 'underline' }}>Privacy Policy</a>
                      </span>
                    </label>
                  </div>

                  <Button type="submit" disabled={loading} className="btn-primary" style={{ width: '100%', height: '44px' }}>
                    {loading ? 'Creating account...' : 'Create Account'} <ArrowRight data-icon="inline-end" size={16} />
                  </Button>
                </form>

                <p className="auth-links">
                  Already have an account?{' '}
                  <button onClick={() => { setMode('signin'); setErrorMsg('') }}>Sign in</button>
                </p>
              </>
            )}
          </>
        )}

        {mode === 'forgot' && (
          <>
            <button
              type="button"
              className="text-link"
              onClick={() => { setMode('signin'); setForgotSent(false); setErrorMsg('') }}
              style={{ marginBottom: '16px' }}
            >
              <ArrowLeft size={16} /> Back to Sign In
            </button>

            <h1>Reset password.</h1>
            <p className="muted">Enter your account email and we&apos;ll send you a secure link to create a new password.</p>

            {forgotSent ? (
              <div className="auth-success-box">
                <CheckCircle2 size={36} color="var(--green)" style={{ margin: '0 auto 12px' }} />
                <h3>Check your inbox</h3>
                <p>We sent a reset link to <strong>{email}</strong>. Please check your spam folder if you don&apos;t see it.</p>
                <Button
                  onClick={() => { setMode('signin'); setForgotSent(false); setErrorMsg('') }}
                  className="btn-primary"
                  style={{ marginTop: '18px', width: '100%' }}
                >
                  Return to Sign In
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="forgot-email">Email Address</label>
                  <input
                    id="forgot-email"
                    className="form-input"
                    required
                    type="email"
                    placeholder="name@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>

                <Button type="submit" disabled={loading} className="btn-primary" style={{ width: '100%', height: '44px' }}>
                  {loading ? 'Sending link...' : 'Send Reset Link'} <ArrowRight data-icon="inline-end" size={16} />
                </Button>
              </form>
            )}

            <p className="auth-links">
              Remembered your password?{' '}
              <button onClick={() => { setMode('signin'); setForgotSent(false); setErrorMsg('') }}>Sign in</button>
            </p>
          </>
        )}
      </div>

      {/* Right Column: Editorial Showcase */}
      <div className="auth-aside">
        <div style={{ height: '30px', display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
          <p className="kicker" style={{ margin: 0 }}>A BETTER WAY TO READ DINNER</p>
        </div>
        <h2 style={{ marginTop: '12px' }}>Good health starts with understanding the small things.</h2>
        <p className="muted" style={{ fontSize: '15px', maxWidth: '420px', marginBottom: '24px', lineHeight: '1.6' }}>
          Photograph any plate of food and instantly unlock actionable calories, macro ratios, and healthy substitutes.
        </p>

        <div style={{ maxWidth: '440px' }}>
          <SampleLabel />
        </div>

        <div style={{ display: 'flex', gap: '20px', marginTop: '28px', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '12px', color: 'var(--muted)', display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
            <Zap size={14} color="var(--green)" /> 98% AI Precision
          </span>
          <span style={{ fontSize: '12px', color: 'var(--muted)', display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
            <ShieldCheck size={14} color="var(--green)" /> Private & Encrypted
          </span>
          <span style={{ fontSize: '12px', color: 'var(--muted)', display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
            <Sparkles size={14} color="var(--green)" /> Tailored to Indian Diets
          </span>
        </div>
      </div>
    </main>
  )
}

export default AuthPage
